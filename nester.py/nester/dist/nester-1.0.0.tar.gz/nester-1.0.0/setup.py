#!/usr/bin/env python
from distutils.core import setup

setup(
    name = "nester",
    version = '1.0.0',
    py_modules = ['nester'],
    author = 'xiaofan',
    author_email = '750657961@qq.com',
    url = 'http://www.xiaofan.org',
    description = "a module exp",

)


